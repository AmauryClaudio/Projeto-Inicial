//variáveis Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 30;
let raio = diametro / 2;

//movimento da Bolinha
let velocidadeXBolinha = 3;
let velocidadeYBolinha = 3;

//variáveis Raquete
let xRaquete = 5;
let yRaquete = 150;
let wRaquete = 10;
let hRaquete = 90;

//movimenta Raquete
let velocidadeXRaquete = 3;
let velocidadeYRaquete = 3;

//Fuções pré-prontas do p5
function setup() {
  createCanvas(600,400);
}

//Funções definidas por mim
function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBolinha();
  mostraRaquete();
  movimentaRaquete();
  verificaColisaoRaquete();
}

function mostraBolinha(){
circle(xBolinha,yBolinha,diametro)

}

function movimentaBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBolinha(){
 //condicionais da bolinha
  if (xBolinha + raio > width || xBolinha - raio < 0){
    velocidadeXBolinha *= -1;
  }
  if (yBolinha - raio < 0 || yBolinha + raio > height){
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(){
  rect(xRaquete,yRaquete,wRaquete,hRaquete)
}
function movimentaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
  }
}

function verificaColisaoRaquete(){
  if (xBolinha - raio < xRaquete + wRaquete && yBolinha - raio < yRaquete + hRaquete && yBolinha + raio > yRaquete){
    velocidadeXBolinha *= -1
  }
}